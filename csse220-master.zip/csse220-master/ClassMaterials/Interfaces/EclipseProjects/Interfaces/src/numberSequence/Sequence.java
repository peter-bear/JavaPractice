package numberSequence;

public interface Sequence {
	int next();
	void reset();
}
