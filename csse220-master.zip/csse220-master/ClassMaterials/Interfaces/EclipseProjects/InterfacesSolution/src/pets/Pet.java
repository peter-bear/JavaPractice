package pets;

public interface Pet {
	
	public void eatFood();
	public boolean isEating();
	public String getName(); 

}
