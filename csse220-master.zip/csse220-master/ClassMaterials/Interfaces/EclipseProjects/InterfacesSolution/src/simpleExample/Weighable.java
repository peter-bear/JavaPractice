package simpleExample;

public interface Weighable {
	
	double getWeightInLbs();

}
