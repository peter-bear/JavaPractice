package textCalculator;

public interface Function {

	String getFunctionName();
	
	double evaluate(double[] operands);
}
