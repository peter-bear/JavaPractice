package simpleExample;

public interface Measurable { // Step two, creating the interface
	double getMeasure();
}
