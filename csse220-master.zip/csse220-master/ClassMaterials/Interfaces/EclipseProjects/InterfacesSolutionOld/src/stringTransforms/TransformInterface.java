package stringTransforms;

public interface TransformInterface {

	String transform(String input);
}
