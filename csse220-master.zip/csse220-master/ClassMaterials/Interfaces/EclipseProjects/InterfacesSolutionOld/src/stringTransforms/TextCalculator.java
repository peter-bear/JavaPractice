package stringTransforms;

public class TextCalculator {

}
