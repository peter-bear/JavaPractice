package textCalculator;

public interface Function {

	//TODO: Based on existing code, detail this interface, then implement Add and Multiply
	
}
