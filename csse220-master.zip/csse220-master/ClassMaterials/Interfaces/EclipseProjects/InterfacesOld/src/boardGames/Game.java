package boardGames;

/**
 * TODO Put here a description of what this class does.
 * 
 * @author <TODO: Your name here>
 */
public interface Game {
	/*
	 * TODO: Add method declarations and documentation according to the
	 * description of Project 9.2 on p. 416 of Big Java 4th edition. You do not have to
	 * provide implementations of the interface yet.
	 */
}
