package fileIO;


public class LevelIO {

	public static void main(String[] args) {
		new LevelIO();
	}

	public LevelIO() {
		//TODO uncomment and write these methods
		//readFile("levels/suprise.txt");
		//writeFile("levels/level1.txt");
	}

	
}