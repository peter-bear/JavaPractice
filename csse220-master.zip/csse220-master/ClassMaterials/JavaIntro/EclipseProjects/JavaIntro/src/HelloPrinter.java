/**
 * Greetings, earthlings.
 * @author Many people, including YOUR-NAME-HERE.
 */
public class HelloPrinter {

	/**
	 * It all begins here.
	 *
	 * @param args Command-line arguments, ignored here.
	 */
	public static void main(String[] args) {
		System.out.println("Hello, World!");
	}
}
