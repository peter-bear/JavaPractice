package function;

import java.util.Comparator;

/**
 * This Comparator orders strings by the number of vowels they contain.
 * 
 * @author Delvin Defoe and you. Created Nov 4, 2015.
 */
public class MostVowelsComparator implements Comparator<String> {

	@Override
	public int compare(String o1, String o2) {
		// TODO implement
		return 0;
	}

}
